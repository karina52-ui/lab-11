#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFileDialog>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    bool ok;
    int a = ui->le_a->text().toInt(&ok);
    if (!ok || a==0) {
        QMessageBox::warning(0,"Error","Number is not valid");
        return;
    }
    int b = ui->le_b->text().toInt(&ok);
    if (!ok || a==0) {
        QMessageBox::warning(0,"Error","Number is not valid");
        return;
    }
    ui->v_sum->setNum(a*a + b*b);
    ui->v_diff->setNum(a*a - b*b);
    ui->v_product->setNum(a*a * b*b);
    ui->v_remainder->setNum((a*a) / (b*b));
}


void MainWindow::on_actionOpen_triggered()
{
    QString filePath = QFileDialog::getOpenFileName(this, "Open File", QDir::currentPath(),"Текстові файли (*.txt);;Усі файли (*)");
    if (!filePath.isEmpty()) {
        QFile file(filePath);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QMessageBox::warning(0,"Error","Can not open file!");
        } else {
            QTextStream in(&file);
            QString a, b, sum, diff, mult, prod, remainder;
            in >> a >> b >> sum >> diff >> prod >> remainder;
            ui->le_a->setText(a);
            ui->le_b->setText(b);
            ui->v_sum->setText(sum);
            ui->v_diff->setText(diff);
            ui->v_product->setText(prod);
            ui->v_remainder->setText(remainder);
        }
    } else {
        QMessageBox::warning(0,"Error","Unknown filename!");
    }

}


void MainWindow::on_actionSave_triggered()
{
    QString filePath = QFileDialog::getOpenFileName(this, "Save File", QDir::currentPath(),"Текстові файли (*.txt);;Усі файли (*)");
    if (!filePath.isEmpty()) {
        QFile file(filePath);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QMessageBox::critical(nullptr,"Error","Can not open file:\n"+file.errorString());
        } else {
            QTextStream out(&file);
            out << ui->le_a->text() << "\n";
            out << ui->le_b->text() << "\n";
            out << ui->v_sum->text() << "\n";
            out << ui->v_diff->text() << "\n";
            out << ui->v_product->text() << "\n";
            out << ui->v_remainder->text() << "\n";
        }
    } else {
        QMessageBox::warning(0,"Error","Unknown filename!");
    }
}

